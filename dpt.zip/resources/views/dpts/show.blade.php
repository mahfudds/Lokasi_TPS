@extends('default')

@section('content')

	{{ $dpt->id }}

@stop