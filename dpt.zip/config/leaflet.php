<?php

return [
    'zoom_level'           => 11,
    'detail_zoom_level'    => 16,
    'map_center_latitude'  => env('MAP_CENTER_LATITUDE', '-7.4025314234522614'),
    'map_center_longitude' => env('MAP_CENTER_LONGITUDE', '111.44014760382927'),
];
