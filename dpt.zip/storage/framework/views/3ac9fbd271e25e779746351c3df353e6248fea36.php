<footer class="text-center fixed-bottom mb-2">
    The source code of this project is available on <a href="https://github.com/nafiesl/laravel-leaflet-example" target="_blank">github</a>.
</footer>
<?php /**PATH D:\SERVER23\htdocs\dpt\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>