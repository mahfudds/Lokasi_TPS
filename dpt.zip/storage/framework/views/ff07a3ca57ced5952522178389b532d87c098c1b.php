<?php $__env->startSection('title', __('outlet.list')); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-3">
    <div class="float-right">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', new App\Outlet)): ?>
            <a href="<?php echo e(route('outlets.create')); ?>" class="btn btn-success"><?php echo e(__('outlet.create')); ?></a>
        <?php endif; ?>
    </div>
    <h1 class="page-title"><?php echo e(__('outlet.list')); ?> <small><?php echo e(__('app.total')); ?> : <?php echo e($outlets->total()); ?> <?php echo e(__('outlet.outlet')); ?></small></h1>
</div>





<div class="col-sm-12">
    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <div class="header-title">
               \
            </div>

        </div>
        <div class="card-body px-2">
            <div class="table-responsive">
                <?php echo $dataTable->table(['class' => 'table text-center table-striped w-100'], true); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SERVER23\htdocs\dpt\resources\views/outlets/index.blade.php ENDPATH**/ ?>