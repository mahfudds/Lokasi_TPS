<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>




<?php $__env->startSection('title', __('outlet.list')); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.0.3/css/buttons.dataTables.min.css">
<div class="card">
    <div class="card-header"></div>
    <div class="card-body">
        <div class="table-responsive">
            <?php echo $dataTable->table(['class' => 'table text-center table-striped w-100'], true); ?>

        </div>
    </div>
</div>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>

<?php $__env->startPush('scripts'); ?>
    <?php echo e($dataTable->scripts()); ?>

<?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SERVER23\htdocs\dpt\resources\views/dpts/index.blade.php ENDPATH**/ ?>