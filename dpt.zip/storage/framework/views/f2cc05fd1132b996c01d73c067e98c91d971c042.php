<?php $__env->startSection('title', __('outlet.list')); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-6">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php echo e(Form::model($dpt, array('route' => array('dpts.update', $dpt->id), 'method' => 'PUT'))); ?>


        <?php echo e(Form::hidden('id', null, array('class' => 'form-control'))); ?>


        <div class="mb-3">
            <?php echo e(Form::label('Kecamatan', 'Kecamatan', ['class'=>'form-label'])); ?>

            <?php echo e(Form::text('Kecamatan', null, ['class' => 'form-control', 'readonly'])); ?>

        </div>
        <div class="mb-3">
            <?php echo e(Form::label('Kelurahan', 'Kelurahan', ['class'=>'form-label'])); ?>

            <?php echo e(Form::text('Kelurahan', null, ['class' => 'form-control', 'readonly'])); ?>

        </div>
        <div class="mb-3">
            <?php echo e(Form::label('Kode_Kelurahan', 'Kode_kelurahan', ['class'=>'form-label'])); ?>

            <?php echo e(Form::text('Kode_Kelurahan', null, ['class' => 'form-control', 'readonly'])); ?>

        </div>
        <div class="mb-3">
            <?php echo e(Form::label('No_TPS', 'No_TPS', ['class'=>'form-label'])); ?>

            <?php echo e(Form::text('No_TPS', null, ['class' => 'form-control', 'readonly'])); ?>

        </div>
        <div class="mb-3">
            <?php echo e(Form::label('Latitude', 'Latitude', ['class'=>'form-label'])); ?>

            <?php echo e(Form::text('Latitude', null, array('class' => 'form-control','id'=>'Latitude','onchange'=>'handleInputValueChange()'))); ?>

        </div>
        <div class="mb-3">
            <?php echo e(Form::label('Longitude', 'Longitude', ['class'=>'form-label'])); ?>

            <?php echo e(Form::text('Longitude', null, array('class' => 'form-control','id'=>'Longitude','onchange'=>'handleInputValueChange()'))); ?>

        </div>
        <div class="mb-3">
            <?php echo e(Form::label('Jumlah_Pemilih', 'Jumlah_pemilih', ['class'=>'form-label'])); ?>

            <?php echo e(Form::text('Jumlah_Pemilih', null, array('class' => 'form-control'))); ?>

        </div>
        <div class="mb-3">
            <?php echo e(Form::label('validasi', 'Validasi', ['class'=>'form-label'])); ?>

            <?php echo e(Form::select('validasi', ['0' => 'Belum Valid', '1' => 'Sudah Valid'], null, ['class' => 'form-control'])); ?>

        </div>

        <?php echo e(Form::submit('Edit', array('class' => 'btn btn-primary'))); ?>


        <?php echo e(Form::close()); ?>

    </div>

    <div class="col-md-6">
        <div id="map" style="height: 500px;"></div>
    </div>
</div>
<style>
    #map-container {
        height: 100%;
        display: flex;
        align-items: stretch;
    }

    #map {
        flex-grow: 1;
    }
</style>
<script src="https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.js"></script>
<script>
    var map;
    var marker;

    function initMap() {
        // Get the initial Latitude and Longitude values from the form
        var initialLatitude = parseFloat('<?php echo e($dpt->Latitude); ?>');
        var initialLongitude = parseFloat('<?php echo e($dpt->Longitude); ?>');

        // Create a map centered at the initial coordinates
        map = L.map('map').setView([initialLatitude, initialLongitude], 14);

        // Add the tile layer (you can use different tile providers)
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors',
            maxZoom: 18,
        }).addTo(map);

        // Add a marker at the initial coordinates
        marker = L.marker([initialLatitude, initialLongitude]).addTo(map);
    }

    function updateMarkerPosition(latitude, longitude) {
        // Update the marker position
        marker.setLatLng([latitude, longitude]);
    }

    function handleInputValueChange() {
        // Get the updated Latitude and Longitude values from the form inputs
        var latitude = parseFloat(document.getElementById('Latitude').value);
        var longitude = parseFloat(document.getElementById('Longitude').value);

        // Update the marker position on the map
        updateMarkerPosition(latitude, longitude);

        // Center the map on the updated coordinates
        map.setView([latitude, longitude]);
    }

    // Listen for input value changes
    document.getElementById('Latitude').addEventListener('input', handleInputValueChange);
    document.getElementById('Longitude').addEventListener('input', handleInputValueChange);

    window.addEventListener('DOMContentLoaded', function() {
        initMap();
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SERVER23\htdocs\dpt\resources\views/dpts/edit.blade.php ENDPATH**/ ?>